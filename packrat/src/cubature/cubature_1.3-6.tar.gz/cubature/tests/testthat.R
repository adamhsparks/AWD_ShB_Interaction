library(testthat)
library(cubature)

test_check("cubature")
